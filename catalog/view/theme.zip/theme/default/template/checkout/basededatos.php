<?php
/**
 * Sistema Creado por Alvaro Rivera para ODRIL Fecha de actualizacion 22/ Septiembre / 2014  22:40 hrs.
 * Se deja registro que se entregan datos conexion a bases de datos TIENDA3
 */

// Datos de Conexion a OPENCART TIENDA 3
$vServer 	=  	"localhost";
$vBd 		=  	"socimage_tienda3";
$vUser 		= 	"socimage_tienda3";
$vPassword 	= 	".10CORzHl2^%";